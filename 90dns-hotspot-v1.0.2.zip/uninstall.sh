#!/system/bin/sh
MODDIR=${0%/*}
[ -f "$MODDIR/nx90.sh" ] && sh "$MODDIR/nx90.sh" stop
rm -rf /data/adb/90dns-hotspot
