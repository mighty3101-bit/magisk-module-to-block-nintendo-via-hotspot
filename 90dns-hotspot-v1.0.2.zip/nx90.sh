#!/system/bin/sh
# ==============================================================================
#  90dns-hotspot — contrôleur
#  Usage : sh nx90.sh {start|stop|restart|status|test|rules|unrules|watch}
#
#  Équivalent « SELFHOST » de 90dns, côté téléphone :
#    - dnsmasq   : domaines Nintendo -> 127.0.0.1, le reste est relayé (1.1.1.1…)
#    - nc        : répondeur HTTP qui imite conntest.nintendowifi.net (X-Organization: Nintendo)
#    - iptables  : tout le DNS (port 53) venant du hotspot est détourné vers notre dnsmasq,
#                  même si la console a un DNS codé en dur (8.8.8.8, etc.)
# ==============================================================================

MODDIR="${NX90_MODDIR:-${0%/*}}"
DATA="${NX90_DATA:-/data/adb/90dns-hotspot}"
RUN="$DATA/run"
CONF="$DATA/config.conf"
GEN="$DATA/dnsmasq.conf"
LOG="$DATA/nx90.log"

mkdir -p "$DATA" "$RUN" 2>/dev/null

log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

load_config() {
  # Valeurs par défaut (utilisées si config.conf est absent ou incomplet)
  HOTSPOT_IFACES="swlan0 ap0 softap0 wlan1 wlan2 rndis0 ncm0 bt-pan"
  SWITCH_MAC=""
  UPSTREAM_DNS="1.1.1.1 1.0.0.1"
  CONNTEST_EMULATION=1
  CONNTEST_IP="192.0.2.1"
  DNS_PORT=5300
  HTTP_PORT=8090
  BLOCK_DOT=1
  BLOCK_IPV6=1
  LOG_QUERIES=0
  # shellcheck disable=SC1090
  [ -f "$CONF" ] && . "$CONF"

  # Validation de la MAC (sinon on ignore le filtre plutôt que de casser les règles)
  if [ -n "$SWITCH_MAC" ]; then
    if echo "$SWITCH_MAC" | grep -Eiq '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'; then
      MACOPT="-m mac --mac-source $SWITCH_MAC"
    else
      log "SWITCH_MAC invalide ($SWITCH_MAC) : filtre MAC ignoré"
      MACOPT=""
    fi
  else
    MACOPT=""
  fi
}

ipt()  { iptables  -w "$@"; }
ipt6() { ip6tables -w "$@"; }

is_running() { [ -f "$1" ] && kill -0 "$(cat "$1" 2>/dev/null)" 2>/dev/null; }

# ------------------------------------------------------------------------------
#  dnsmasq
# ------------------------------------------------------------------------------
find_dnsmasq() {
  for p in "$DATA/dnsmasq" "$MODDIR/bin/dnsmasq" /system/bin/dnsmasq /system/xbin/dnsmasq /vendor/bin/dnsmasq; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  return 1
}

gen_conf() {
  {
    echo "# Généré par 90dns-hotspot — NE PAS ÉDITER (voir config.conf et custom-blocklist.txt)"
    echo "port=$DNS_PORT"
    echo "user=root"
    echo "keep-in-foreground"
    echo "pid-file=$RUN/dnsmasq.pid"
    echo "log-facility=$DATA/dnsmasq.log"
    [ "$LOG_QUERIES" = "1" ] && echo "log-queries"
    echo "no-resolv"
    echo "no-hosts"
    echo "no-poll"
    echo "cache-size=1000"
    for s in $UPSTREAM_DNS; do echo "server=$s"; done

    # Émulation du test de connexion (le plus spécifique l'emporte sur nintendowifi.net)
    if [ "$CONNTEST_EMULATION" = "1" ]; then
      echo "address=/conntest.nintendowifi.net/$CONNTEST_IP"
      echo "address=/ctest.cdn.nintendo.net/$CONNTEST_IP"
    fi

    # Blocage : domaine + sous-domaines -> 127.0.0.1
    for f in "$DATA/blocklist.txt" "$DATA/custom-blocklist.txt"; do
      [ -f "$f" ] || continue
      sed -e 's/#.*//' -e 's/\r//' -e 's/[[:space:]]//g' -e 's/^\*\.//' -e 's/^\.//' "$f" \
        | tr 'A-Z' 'a-z' \
        | grep -E '^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$' \
        | while read -r d; do echo "address=/$d/127.0.0.1"; done
    done
  } > "$GEN"
}

start_dns() {
  DNSMASQ="$(find_dnsmasq)" || { log "ERREUR : dnsmasq introuvable (voir README)"; return 1; }
  gen_conf || { log "ERREUR : génération de la config dnsmasq"; return 1; }
  out="$("$DNSMASQ" --test --conf-file="$GEN" 2>&1)"
  if [ $? -ne 0 ]; then
    log "ERREUR : dnsmasq --test a rejeté la configuration : $out"
    n="$(echo "$out" | sed -n 's/.*at line \([0-9][0-9]*\).*/\1/p' | head -n 1)"
    [ -n "$n" ] && log "  ligne $n de dnsmasq.conf : $(sed -n "${n}p" "$GEN")"
    return 1
  fi
  rm -f "$RUN/dnsmasq.pid"
  "$DNSMASQ" --conf-file="$GEN" >> "$LOG" 2>&1 &
  i=0
  while [ "$i" -lt 10 ]; do
    is_running "$RUN/dnsmasq.pid" && break
    sleep 1; i=$((i + 1))
  done
  if is_running "$RUN/dnsmasq.pid"; then
    log "dnsmasq démarré (pid $(cat "$RUN/dnsmasq.pid"), port $DNS_PORT)"
  else
    log "ERREUR : dnsmasq ne démarre pas"
    return 1
  fi
}

stop_dns() {
  is_running "$RUN/dnsmasq.pid" && kill "$(cat "$RUN/dnsmasq.pid")" 2>/dev/null
  rm -f "$RUN/dnsmasq.pid"
}

# ------------------------------------------------------------------------------
#  Répondeur HTTP « conntest » (remplace nginx)
#  La console fait GET http://conntest.nintendowifi.net/ et attend 200 + X-Organization: Nintendo
# ------------------------------------------------------------------------------
start_http() {
  [ "$CONNTEST_EMULATION" = "1" ] || return 0
  stop_http
  TMO=""
  command -v timeout >/dev/null 2>&1 && TMO="timeout 15"
  (
    while :; do
      printf 'HTTP/1.1 200 OK\r\nX-Organization: Nintendo\r\nContent-Type: text/plain\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok' \
        | $TMO nc -l -p "$HTTP_PORT" > /dev/null 2>&1 || sleep 1
    done
  ) &
  echo $! > "$RUN/http.pid"
  log "répondeur conntest démarré (port $HTTP_PORT)"
}

stop_http() {
  is_running "$RUN/http.pid" && kill "$(cat "$RUN/http.pid")" 2>/dev/null
  rm -f "$RUN/http.pid"
  pkill -f "nc -l -p $HTTP_PORT" 2>/dev/null
}

# ------------------------------------------------------------------------------
#  iptables
# ------------------------------------------------------------------------------
remove_rules() {
  # IPv4
  while ipt -t nat -D PREROUTING -j NX90DNS 2>/dev/null; do :; done
  ipt -t nat -F NX90DNS 2>/dev/null; ipt -t nat -X NX90DNS 2>/dev/null
  while ipt -D FORWARD -j NX90DNS_F 2>/dev/null; do :; done
  ipt -F NX90DNS_F 2>/dev/null; ipt -X NX90DNS_F 2>/dev/null
  # IPv6
  while ipt6 -t nat -D PREROUTING -j NX90DNS 2>/dev/null; do :; done
  ipt6 -t nat -F NX90DNS 2>/dev/null; ipt6 -t nat -X NX90DNS 2>/dev/null
  while ipt6 -D FORWARD -j NX90DNS_F6 2>/dev/null; do :; done
  while ipt6 -D INPUT   -j NX90DNS_F6 2>/dev/null; do :; done
  ipt6 -F NX90DNS_F6 2>/dev/null; ipt6 -X NX90DNS_F6 2>/dev/null
  while ipt6 -D FORWARD -j NX90DNS_V6 2>/dev/null; do :; done
  ipt6 -F NX90DNS_V6 2>/dev/null; ipt6 -X NX90DNS_V6 2>/dev/null
}

apply_rules() {
  remove_rules

  # --- IPv4 : détourner le DNS du hotspot vers dnsmasq + le test de connexion vers le répondeur
  if ! ipt -t nat -N NX90DNS 2>/dev/null; then
    log "ERREUR : impossible de créer la chaîne nat (iptables indisponible ?)"
    return 1
  fi
  for IF in $HOTSPOT_IFACES; do
    ipt -t nat -A NX90DNS -i "$IF" -p udp --dport 53 $MACOPT -j REDIRECT --to-ports "$DNS_PORT"
    ipt -t nat -A NX90DNS -i "$IF" -p tcp --dport 53 $MACOPT -j REDIRECT --to-ports "$DNS_PORT"
    if [ "$CONNTEST_EMULATION" = "1" ]; then
      ipt -t nat -A NX90DNS -i "$IF" -p tcp -d "$CONNTEST_IP" --dport 80 -j REDIRECT --to-ports "$HTTP_PORT"
    fi
  done
  ipt -t nat -I PREROUTING 1 -j NX90DNS

  # --- IPv4 : refuser le DNS-over-TLS (sinon la console pourrait contourner le filtre)
  if [ "$BLOCK_DOT" = "1" ]; then
    ipt -N NX90DNS_F 2>/dev/null
    for IF in $HOTSPOT_IFACES; do
      ipt -A NX90DNS_F -i "$IF" -p tcp --dport 853 $MACOPT -j REJECT --reject-with tcp-reset
      ipt -A NX90DNS_F -i "$IF" -p udp --dport 853 $MACOPT -j REJECT
    done
    ipt -I FORWARD 1 -j NX90DNS_F
  fi

  # --- IPv6 : détournement si le noyau gère le NAT6, sinon on refuse le DNS v6
  #     (le client retombe alors sur le DNS IPv4 donné par le DHCP, qui est filtré)
  ipt6 -N NX90DNS_F6 2>/dev/null
  if ipt6 -t nat -N NX90DNS 2>/dev/null; then
    for IF in $HOTSPOT_IFACES; do
      ipt6 -t nat -A NX90DNS -i "$IF" -p udp --dport 53 $MACOPT -j REDIRECT --to-ports "$DNS_PORT"
      ipt6 -t nat -A NX90DNS -i "$IF" -p tcp --dport 53 $MACOPT -j REDIRECT --to-ports "$DNS_PORT"
    done
    ipt6 -t nat -I PREROUTING 1 -j NX90DNS
    V6="nat6"
  else
    for IF in $HOTSPOT_IFACES; do
      ipt6 -A NX90DNS_F6 -i "$IF" -p udp --dport 53 $MACOPT -j REJECT
      ipt6 -A NX90DNS_F6 -i "$IF" -p tcp --dport 53 $MACOPT -j REJECT --reject-with tcp-reset
    done
    V6="reject"
  fi
  if [ "$BLOCK_DOT" = "1" ]; then
    for IF in $HOTSPOT_IFACES; do
      ipt6 -A NX90DNS_F6 -i "$IF" -p tcp --dport 853 $MACOPT -j REJECT --reject-with tcp-reset
      ipt6 -A NX90DNS_F6 -i "$IF" -p udp --dport 853 $MACOPT -j REJECT
    done
  fi
  ipt6 -I FORWARD 1 -j NX90DNS_F6
  ipt6 -I INPUT   1 -j NX90DNS_F6

  # --- IPv6 : couper tout l'IPv6 ROUTÉ depuis le hotspot. Le blocage étant fait par DNS,
  #     une adresse IPv6 Nintendo « en dur » passerait ; la console retombe ainsi sur l'IPv4,
  #     entièrement filtré. (Uniquement FORWARD : le NDP / ICMPv6 vers le téléphone reste intact.)
  if [ "$BLOCK_IPV6" = "1" ]; then
    ipt6 -N NX90DNS_V6 2>/dev/null
    for IF in $HOTSPOT_IFACES; do
      ipt6 -A NX90DNS_V6 -i "$IF" $MACOPT -j REJECT --reject-with icmp6-adm-prohibited
    done
    ipt6 -I FORWARD 1 -j NX90DNS_V6
    V6="$V6 + trafic IPv6 coupé"
  fi

  log "règles iptables appliquées (interfaces : $HOTSPOT_IFACES ; IPv6 : $V6)"
}

rules_ok() {
  ipt -t nat -C PREROUTING -j NX90DNS > /dev/null 2>&1 || return 1
  if [ "$BLOCK_DOT" = "1" ]; then
    ipt -C FORWARD -j NX90DNS_F > /dev/null 2>&1 || return 1
  fi
  if [ "$BLOCK_IPV6" = "1" ] && command -v ip6tables > /dev/null 2>&1; then
    ipt6 -C FORWARD -j NX90DNS_V6 > /dev/null 2>&1 || return 1
  fi
  return 0
}

# ------------------------------------------------------------------------------
#  Orchestration
# ------------------------------------------------------------------------------
start_all() {
  # Les règles de détournement ne sont posées que si dnsmasq tourne : sinon le DNS
  # des appareils du hotspot partirait vers un port mort et ils perdraient Internet.
  start_dns || return 1
  start_http
  apply_rules
}

stop_all() {
  stop_http
  stop_dns
  remove_rules
  log "arrêté"
}

# Boucle de surveillance : relance dnsmasq / le répondeur et réapplique les règles
# si le système (netd) les a effacées, par ex. quand le hotspot est rallumé.
watch() {
  # Un seul watchdog à la fois
  if is_running "$RUN/watch.pid" && [ "$(cat "$RUN/watch.pid")" != "$$" ]; then exit 0; fi
  echo $$ > "$RUN/watch.pid"
  load_config
  if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 524288 ]; then : > "$LOG"; fi
  log "=== démarrage (watchdog pid $$) ==="
  start_all
  fails=0
  while :; do
    sleep 10
    if [ -f "$MODDIR/disable" ] || [ -f "$MODDIR/remove" ]; then
      log "module désactivé : arrêt"
      stop_all
      rm -f "$RUN/watch.pid"
      exit 0
    fi
    if ! is_running "$RUN/dnsmasq.pid"; then
      log "dnsmasq arrêté : redémarrage"
      if start_dns; then
        fails=0
      else
        fails=$((fails + 1))
        # Échecs répétés : on retire le détournement pour ne pas couper Internet au hotspot
        if [ "$fails" -ge 3 ] && rules_ok; then
          log "ATTENTION : dnsmasq ne repart pas, règles retirées (le hotspot reste fonctionnel mais NON filtré)"
          remove_rules
        fi
        [ "$fails" -gt 5 ] && sleep 60
      fi
    fi
    if [ "$CONNTEST_EMULATION" = "1" ] && ! is_running "$RUN/http.pid"; then
      start_http
    fi
    if is_running "$RUN/dnsmasq.pid" && ! rules_ok; then
      log "règles iptables absentes : réapplication"
      apply_rules
    fi
  done
}

# ------------------------------------------------------------------------------
#  Diagnostics
# ------------------------------------------------------------------------------

# Interroge notre dnsmasq (127.0.0.1:$DNS_PORT) et affiche la dernière adresse A de la réponse
dnsq() {
  _q=""
  _old=$IFS; IFS=.
  for _l in $1; do _q="$_q$(printf '\\%03o' "${#_l}")$_l"; done
  IFS=$_old
  set -- $(printf "\\222\\064\\001\\000\\000\\001\\000\\000\\000\\000\\000\\000${_q}\\000\\000\\001\\000\\001" \
            | nc -u -w 2 127.0.0.1 "$DNS_PORT" 2>/dev/null | od -An -v -tu1)
  if [ "$#" -lt 16 ]; then echo "pas de réponse"; return 1; fi
  _rcode=$(( $4 % 16 ))
  _an=$(( $7 * 256 + $8 ))
  if [ "$_rcode" -ne 0 ]; then echo "erreur DNS (rcode $_rcode)"; return 1; fi
  if [ "$_an" -eq 0 ]; then echo "(aucune adresse A)"; return 0; fi
  shift $(( $# - 4 ))
  echo "$1.$2.$3.$4"
}

check() {  # $1=nom  $2=attendu (vide = n'importe quelle adresse)
  got="$(dnsq "$1")"
  if [ -z "$2" ]; then
    case "$got" in *.*.*.*) st="OK";; *) st="KO";; esac
  else
    [ "$got" = "$2" ] && st="OK" || st="KO"
  fi
  printf '  [%s] %-28s -> %s\n' "$st" "$1" "$got"
}

run_test() {
  load_config
  if ! is_running "$RUN/dnsmasq.pid"; then
    echo "dnsmasq est arrêté : impossible de tester. Regarde le journal :"
    tail -n 6 "$LOG" 2>/dev/null | sed 's/^/  | /'
    return 1
  fi
  echo "Auto-test (dnsmasq local, port $DNS_PORT) :"
  check example.nintendo.com 127.0.0.1
  check ctest.cdn.nintendo.net "$([ "$CONNTEST_EMULATION" = "1" ] && echo "$CONNTEST_IP" || echo 127.0.0.1)"
  check conntest.nintendowifi.net "$([ "$CONNTEST_EMULATION" = "1" ] && echo "$CONNTEST_IP" || echo 127.0.0.1)"
  check example.com ""
  if [ "$CONNTEST_EMULATION" = "1" ]; then
    echo "Répondeur conntest (127.0.0.1:$HTTP_PORT) :"
    printf 'GET / HTTP/1.1\r\nHost: conntest.nintendowifi.net\r\n\r\n' \
      | nc -w 3 127.0.0.1 "$HTTP_PORT" 2>/dev/null | tr -d '\r' | sed -n '1p;/^X-Organization/p' | sed 's/^/  /'
  fi
  echo
  echo "À faire ensuite depuis la Switch 2 (ou un PC sur le hotspot) :"
  echo "  - Switch : Paramètres > Internet > Test de connexion"
  echo "  - PC     : nslookup example.nintendo.com  (doit répondre 127.0.0.1)"
}

run_status() {
  load_config
  echo "== 90DNS Hotspot =="
  if is_running "$RUN/watch.pid";   then echo "watchdog : actif (pid $(cat "$RUN/watch.pid"))";   else echo "watchdog : arrêté"; fi
  if is_running "$RUN/dnsmasq.pid"; then echo "dnsmasq  : actif (pid $(cat "$RUN/dnsmasq.pid"), port $DNS_PORT)"; else echo "dnsmasq  : arrêté"; fi
  if [ "$CONNTEST_EMULATION" = "1" ]; then
    if is_running "$RUN/http.pid";  then echo "conntest : actif (port $HTTP_PORT)"; else echo "conntest : arrêté"; fi
  else
    echo "conntest : désactivé (tout est bloqué)"
  fi
  if rules_ok; then echo "iptables : règles en place"; else echo "iptables : règles ABSENTES"; fi
  [ "$BLOCK_IPV6" = "1" ] && echo "IPv6     : coupé pour le hotspot" || echo "IPv6     : laissé actif"
  echo "interfaces : $HOTSPOT_IFACES"
  [ -n "$SWITCH_MAC" ] && echo "filtre MAC : $SWITCH_MAC" || echo "filtre MAC : aucun (tous les appareils du hotspot)"
  echo "domaines bloqués : $(grep -c '^address=/.*/127.0.0.1$' "$GEN" 2>/dev/null)"
  echo "journal : $LOG"
  tail -n 5 "$LOG" 2>/dev/null | sed 's/^/  | /'
}

main() {
  case "$1" in
    start)   load_config; start_all ;;
    stop)    load_config
             is_running "$RUN/watch.pid" && kill "$(cat "$RUN/watch.pid")" 2>/dev/null
             rm -f "$RUN/watch.pid"; stop_all ;;
    restart) sh "$0" stop; sleep 1; nohup sh "$0" watch > /dev/null 2>&1 & ;;
    watch)   watch ;;
    rules)   load_config; apply_rules ;;
    unrules) load_config; remove_rules ;;
    status)  run_status ;;
    test)    run_test ;;
    *)       echo "Usage : sh $0 {start|stop|restart|status|test|rules|unrules|watch}"; exit 1 ;;
  esac
}

# NX90_SOURCE_ONLY=1 permet de « sourcer » le script pour le tester sans l'exécuter
[ -n "$NX90_SOURCE_ONLY" ] || main "$@"
