# 90DNS Hotspot — blocage Nintendo sur le point d'accès Wi-Fi

Module Magisk (aussi KernelSU / APatch) qui reprend le principe de **90dns SELFHOST**
(https://gitlab.com/a/90dns) directement sur le téléphone : tout appareil connecté au
**point d'accès mobile** (donc ta Switch 2) ne peut plus joindre les serveurs Nintendo.

| 90dns SELFHOST            | Ce module                                                        |
|---------------------------|------------------------------------------------------------------|
| dnsmasq + liste de domaines | `/system/bin/dnsmasq` d'Android, mêmes domaines → `127.0.0.1`   |
| nginx (conntest)          | mini répondeur `nc` : `200 OK` + `X-Organization: Nintendo`      |
| « mets ce DNS dans la console » | iptables détourne **tout** le DNS du hotspot vers dnsmasq : rien à régler sur la console, et un DNS codé en dur (8.8.8.8…) est intercepté aussi |
| forward vers 1.1.1.1…     | idem (`UPSTREAM_DNS`)                                            |

Bonus : DNS-over-TLS (853) refusé depuis le hotspot, **IPv6 routé coupé** (`BLOCK_IPV6=1`, la console retombe sur l'IPv4 filtré), watchdog qui relance tout
et réapplique les règles quand Android réinitialise le réseau.

## Installation
1. Magisk → Modules → *Installer depuis le stockage* → ce zip → **redémarrer**.
2. Allume le point d'accès, connecte la Switch 2 **sans changer ses réglages DNS** (automatique).

## Vérifier
```
su -c "sh /data/adb/modules/90dns-hotspot/nx90.sh status"
su -c "sh /data/adb/modules/90dns-hotspot/nx90.sh test"
```
(ou bouton **Action** du module sous Magisk 28+). Depuis un PC sur le hotspot :
`nslookup example.nintendo.com` → `127.0.0.1`.

## Portée : où ça s'applique
Uniquement aux interfaces de `HOTSPOT_IFACES`, donc quand **ce téléphone** fait le hotspot (Wi-Fi, USB, Bluetooth).
Rien n'est modifié sur le Wi-Fi du téléphone (`wlan0`), ni sur un autre réseau où la console se connecterait.
Le filtre vaut pour tous les appareils du hotspot, sauf si `SWITCH_MAC` est renseigné.

## Réglages — `/data/adb/90dns-hotspot/config.conf`
Puis : `su -c "sh /data/adb/modules/90dns-hotspot/nx90.sh restart"`
- `HOTSPOT_IFACES` : interface du hotspot (hotspot allumé : `su -c "ip -4 addr"`, cherche `192.168.x.1`).
  Par défaut : `swlan0 ap0 softap0 wlan1 wlan2 rndis0 ncm0 bt-pan`.
- `BLOCK_IPV6` : 1 (défaut) = coupe l'IPv6 routé depuis le hotspot ; 0 = le laisse passer.
- `SWITCH_MAC` : ne filtrer que la console (sinon tous les appareils du hotspot).
- `CONNTEST_EMULATION=0` : bloquer aussi le test de connexion (la console dira « pas d'Internet »).
- `LOG_QUERIES=1` : journalise les requêtes DNS (`dnsmasq.log`) pour repérer d'autres domaines Nintendo,
  à ajouter dans `custom-blocklist.txt`.

## Limites (à savoir)
- **Blocage par DNS uniquement**, comme 90dns : une connexion vers une IPv4 codée en dur n'est pas bloquée (l'IPv6, lui, est coupé).
- 90dns a été conçu pour la Switch 1 ; la Switch 2 peut utiliser d'autres domaines ou contrôles.
  Le module n'a pas pu être testé sur une vraie Switch 2 : utilise `LOG_QUERIES` pour affiner.
- Effets : plus d'eShop, de mises à jour, de jeu en ligne, de cloud saves, etc.
- Si `dnsmasq` est absent du ROM : dépose un binaire arm64 dans `/data/adb/90dns-hotspot/dnsmasq` (chmod 755).
- Si dnsmasq ne repart pas 3 fois de suite, le module retire le détournement (le hotspot garde Internet
  mais n'est plus filtré) et l'écrit dans `nx90.log`.

## Désinstallation
Supprimer le module dans Magisk et redémarrer (règles et dossier `/data/adb/90dns-hotspot` retirés).
Pour un arrêt immédiat sans redémarrer : `su -c "sh /data/adb/modules/90dns-hotspot/nx90.sh stop"`.
