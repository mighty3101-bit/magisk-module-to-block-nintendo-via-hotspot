#!/system/bin/sh
# Bouton "Action" du module : affiche l'état + lance l'auto-test
MODDIR=${0%/*}
sh "$MODDIR/nx90.sh" status
echo
sh "$MODDIR/nx90.sh" test
