#!/system/bin/sh
# Lancé par Magisk au boot (late_start service)
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 3; done
sleep 5
nohup sh "$MODDIR/nx90.sh" watch >/dev/null 2>&1 &
