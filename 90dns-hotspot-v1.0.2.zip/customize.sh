#!/system/bin/sh
# Exécuté par l'installateur Magisk / KernelSU / APatch
DATA=/data/adb/90dns-hotspot

ui_print "- 90DNS Hotspot : blocage Nintendo sur le point d'accès"

if [ "$API" -lt 30 ] 2>/dev/null; then
  ui_print "! Android trop ancien (API $API) : non testé"
fi

# dnsmasq : celui du système (utilisé par le hotspot) ou un binaire fourni
if [ -x /system/bin/dnsmasq ] || [ -x /system/xbin/dnsmasq ] || [ -x /vendor/bin/dnsmasq ]; then
  ui_print "- dnsmasq système trouvé"
else
  ui_print "! dnsmasq introuvable sur ce ROM."
  ui_print "  Dépose un binaire arm64 dans $DATA/dnsmasq (chmod 755)"
  ui_print "  avant de redémarrer (voir README)."
fi

# Dossier persistant (conservé lors des mises à jour du module)
mkdir -p "$DATA/run"
[ -f "$DATA/config.conf" ]           || cp "$MODPATH/defaults/config.conf" "$DATA/config.conf"
[ -f "$DATA/custom-blocklist.txt" ]  || cp "$MODPATH/defaults/custom-blocklist.txt" "$DATA/custom-blocklist.txt"
cp -f "$MODPATH/defaults/blocklist.txt" "$DATA/blocklist.txt"   # liste officielle : toujours mise à jour
chmod 700 "$DATA"
ui_print "- Config : $DATA/config.conf"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/nx90.sh"     0 0 0755
set_perm "$MODPATH/service.sh"  0 0 0755
set_perm "$MODPATH/action.sh"   0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

ui_print "- Redémarre le téléphone pour activer le module."
